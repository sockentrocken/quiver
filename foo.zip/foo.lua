function foo()
	print("bar")
end
